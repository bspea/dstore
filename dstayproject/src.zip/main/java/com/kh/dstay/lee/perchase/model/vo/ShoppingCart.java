package com.kh.dstay.lee.perchase.model.vo;

import java.sql.Date;

public class ShoppingCart {

	private int cno;
	private int pno;
	private int mno;
	private int ccount;
	private Date cdate;
	private String cstatus;
	
	
	
	
	
}
