package com.kh.dstay.lee.login.model.service;

import com.kh.dstay.lee.login.model.vo.Member;

public interface LoginService {
	
	// 1. 임시 로그인용 서비스
	Member loginUser(Member mem);
	
	
	
}
