package com.kh.dstay.lee.perchase.model.dao;

public class ShoppingCartDao {

}
