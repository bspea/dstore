package com.kh.dstay.suggestion.model.service;

import com.kh.dstay.suggestion.model.vo.Suggestion;

public interface SuggestionService {

	int insertSuggestion(Suggestion s);

}
