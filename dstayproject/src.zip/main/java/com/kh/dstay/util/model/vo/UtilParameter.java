package com.kh.dstay.util.model.vo;

import org.springframework.stereotype.Component;
import lombok.Getter;

@Getter@Component
public class UtilParameter {

	private String googleClientId = "772225320155-psolb8vekpte4t7h2bl88b0tt3p3sfn6.apps.googleusercontent.com";
	private String naverClientId = "s6CPRgwP1X7_hKKChRiV";
	private String kakaoJavascriptKey = "b6ca5845154feff6cc055835f1f75513";
	
}
