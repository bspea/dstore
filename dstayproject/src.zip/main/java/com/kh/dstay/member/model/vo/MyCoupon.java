package com.kh.dstay.member.model.vo;

import java.sql.Date;

public class MyCoupon {
	
	private int couponNo;
	private int memberNo;
	private int couponInfoNo;
	private int productNo;
	private int couponCode;
	private String couponName;
	private double saleRate;
	private Date startDate;
	private Date endDate;
	private String status;

}
